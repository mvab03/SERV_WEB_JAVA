import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ScientificCalculatorTest {

    private ScientificCalculator calculator;

    // Item 4 - roda antes de cada teste e cria a calculadora
    @BeforeEach
    public void setUp() {
        calculator = new ScientificCalculator();
    }

    // ===== Operações básicas =====

    // Item 2
    @Test
    public void testAddition() {
        double resultado = calculator.add(2, 3);
        assertEquals(5, resultado);
    }

    // Item 3 - as 4 fases
    @Test
    public void testSubtractionReturnsDifference() {
        // Setup
        double a = 10;
        double b = 4;

        // Execution
        double resultado = calculator.subtract(a, b);

        // Assertion
        assertEquals(6, resultado);

        // Teardown
        // não precisa, pois não tem nenhum recurso para liberar
    }

    // Item 4 - outro teste usando o mesmo objeto "calculator" criado no @BeforeEach
    @Test
    public void testMultiplication() {
        assertEquals(20, calculator.multiply(4, 5));
    }

    // ===== Raiz quadrada =====

    // Item 5 - happy path
    @Test
    public void testSquareRootPositive() {
        assertEquals(4, calculator.squareRoot(16));
    }

    // ===== Testes de erro (exceções) =====

    // Item 6 - corner case
    @Test
    public void testSquareRootNegative() {
        assertThrows(IllegalArgumentException.class, () -> calculator.squareRoot(-4));
    }

    // Item 7
    @Test
    public void testDivideByZero() {
        assertThrows(IllegalArgumentException.class, () -> calculator.divide(10, 0));
    }

    // ===== Logaritmo =====

    // Item 8
    @Test
    public void testLogOfEReturnsOne() {
        assertEquals(1, calculator.log(Math.E), 0.0001);
    }

    @Test
    public void testLogOfOneReturnsZero() {
        assertEquals(0, calculator.log(1), 0.0001);
    }

    // ===== Funções trigonométricas =====

    // Item 8
    @Test
    public void testSinOf30DegreesReturnsHalf() {
        assertEquals(0.5, calculator.sin(30), 0.0001);
    }

    @Test
    public void testSinOf90DegreesReturnsOne() {
        assertEquals(1, calculator.sin(90), 0.0001);
    }
}
